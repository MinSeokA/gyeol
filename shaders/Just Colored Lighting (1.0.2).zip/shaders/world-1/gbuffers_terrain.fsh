#version 430 compatibility

#define FILTER_HERE UPSCALE_TERRAIN

#define IS_THE_NETHER 1
#define IS_TERRAIN 1

#define HARD_ALPHA 1
#include "/main_f.glsl"
